import React from 'react';
import MyComponent from './components/MyComponent.js';
import Wrapper from './components/Wrapper.js';
import Title from './components/Title.js';
import Food from './components/Food.js';
import Alert from './components/Alert.js';

// const App = () => (
//   <div>
//     <p>Read the README.md to see the tasks</p>
//   </div>
// );

export default function App({ value }) {
  const [inputValue, setInputValue] = React.useState('');
  //const food = [{id: 1, name: 'Pizza'}, {id: 2, name: 'Hamburger'}, {id: 3, name: 'Coke'}];
  return (
    <main>
      <MyComponent />
      <Wrapper>
        <Title title="Test" />
      </Wrapper>
      <Food />
      <Alert>{setInputValue}</Alert>
      <p>{inputValue}</p>
    </main>
  );
}
