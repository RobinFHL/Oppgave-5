export default function Title() {
  return (
    <>
      <h1>{'It Works'}</h1>
    </>
  );
}
