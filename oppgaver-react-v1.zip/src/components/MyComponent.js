import Title from './Title.js';

export default function MyComponent({ title }) {
  return (
    <>
      <Title />
    </>
  );
}

//const render = <MyComponent title = {"It Works"}/>
