export default function Food({ value }) {
  const food = [
    { id: 1, name: 'Pizza' },
    { id: 2, name: 'Hamburger' },
    { id: 3, name: 'Coke' }
  ];
  return (
    <ul>
      {food.map((value) => (
        <li key={value.id}>{value.name}</li>
      ))}
      ;
    </ul>
  );
}
