import React from 'react';

export default function Alert() {
  const [name, setName] = React.useState('default');

  function handleChange(e) {
    setName(e.target.value);
  }
  return (
    <>
      <button onClick={() => console.log(name)}></button>
      <input autoFocus onChange={handleChange} />
    </>
  );
}
